class Inimigo:Personagem{
    //private bool aliado;
    private int agressividade;
    private int curarAliado;
    private int autoProtecao;
    private int protegerAliado;
   

}

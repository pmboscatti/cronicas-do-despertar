class Acao{
    public string nome;
    public int pp;//powerpoint
    public int precisao;
    public bool erraAcao()
    {
        return RNJesus.erraAcao(precisao);
    }
}

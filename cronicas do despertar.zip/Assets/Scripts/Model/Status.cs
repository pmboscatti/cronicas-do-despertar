class Status: Acao{
    public int nivelBuff;// vai de -6 a +6 
    public int buff;

}

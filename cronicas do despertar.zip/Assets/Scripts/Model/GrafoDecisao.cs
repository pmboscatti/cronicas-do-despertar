class GrafoDecisao{
    private Inimigo personagem;
    private int [] saida;
    private int [] destino;
    int []peso;

    public GrafoDecisao(Inimigo ator){
        this.personagem=ator;
    }
    // public void criarGrafo()
    // { 
    //     //iterar pelo vetor de peso, atribuindo o valor de peso de cada um
    // }
    // private int consigoUsarMagia()
    // {
    //     int peso=1000000000;
    //     if(possuiMagia)
    //     {
            
    //     }
    // }
    // private bool possuiMagia()
    // {

    // }
    // private int consigoUsarAtaqueFisico()
    // {
        
    // }
    // private int consigoUsarStatus()
    // {
        
    // }
    // private int estouComVidaBaixa()
    // {

    // }
    // private int inimigoEstaAoMeuAlcance()
    // {

    // }
    // private int corroRiscoDeNaoSobreviver()
    // {

    // }
    // private int consigoEfetuarUmDebuff()
    // {

    // }
    // private int consigoEfetuarUmDebuff()
    // {

    // }
    // private int aliadoEstaComVidaBaixa()
    // {

    // }
    // private int consigoEliminarOInimigo()
    // {

    // }
    
    // private int aliadoEstaAoMeuAlcance()
    // {

    // }
    // private int aliadoConseguiraSobreviverAoTurno()
    // {

    // }
    // private int buffCalculo()
    // {

    // }
    // private int debuffCalculo()
    // {

    // }
    
}


class Cura: Acao{
    public int cura;
}